﻿
using System;
using System.Threading;

class Program
{
    static void Main(string[] args)
    {
        static pet CreatePet()// By Surushti Mahida
        {
            Console.WriteLine("Welcome to the Virtual Pet Simulator!");
            Console.Write("Choose a pet type (Cat, Dog, Rabbit): ");
            string type = Console.ReadLine();
            Console.Write("Give your pet a name: ");
            string name = Console.ReadLine();
            pet pet = new pet(type, name);
            Console.WriteLine($"Welcome, {pet.Name} the {pet.Type}!");
            return pet;
        }

        {
            pet pet = CreatePet();
            bool isRunning = true;

            while (isRunning)
            {
                Console.Clear();
                DisplayPetStatus(pet);
                Console.WriteLine("add pet actions: what would you like to do?");
                Console.WriteLine("1. Feed", "2. Play", "3. Rest", "5. Exit");
                Console.Write("Choose an option (1-4): ");
                string actions = Console.ReadLine();
                switch (actions)
                {
                    case "1":
                        pet.Feed();
                        break;
                    case "2":
                        pet.Play();
                        break;
                    case "3":
                        pet.Rest();
                        break;
                    case "4":
                        isRunning = false;
                        break;
                    default:
                        Console.WriteLine("Entered invalid action. Please choose again.");
                        break;
                }
                // Simulate 
                pet.PassTime();
                Thread.Sleep(1000);
            }
        }
        static void DisplayPetStatus(pet pet)
        {
            Console.WriteLine($"\nPet Name: {pet.Name}");
            Console.WriteLine($"Pet Type: {pet.Type}");
            Console.WriteLine($"Hunger: {pet.Hunger}/10");
            Console.WriteLine($"Happiness: {pet.Happiness}/10");
            Console.WriteLine($"Health: {pet.Health}/10");

            if (pet.Hunger <= 2 || pet.Happiness <= 2)
            {
                Console.WriteLine("Warning");
            }
        }
    }
    class pet
    {
        public string Type { get; }
        public string Name { get; }
        public int Happiness { get; private set; }
        public int Health { get; private set; }
        public int Hunger { get; private set; }
        public pet(string type, string name)
        {
            Type = type;
            Name = name;
            Hunger = 5;
            Happiness = 5;
            Health = 5;
        }

        public void Feed()
        {
            if (Hunger < 10)
            {
                Hunger += 2;
                Happiness += 1;
                Health += 1;
                Console.WriteLine($"{Name} has been fed. Hunger: {Hunger}, Happiness: {Happiness}, Health: {Health}");
            }
            else
            {
                Console.WriteLine($"{Name} is not hungry!");
            }
        }

        public void Play()
        {
            if (Happiness < 10 && Hunger > 2)
            {
                Happiness += 2;
                Hunger -= 1;
                Console.WriteLine($"{Name} is playing! Happiness: {Happiness}, Hunger: {Hunger}");
            }
            else if (Hunger <= 2)
            {
                Console.WriteLine($"{Name} is too hungry!");
            }
            else
            {
                Console.WriteLine($"{Name} is very happy!");
            }
        }

        public void Rest()
        {
            if (Health < 10)
            {
                Health += 2;
                Happiness -= 1;
                Console.WriteLine($"{Name} is sleeping and resting. Health: {Health}, Happiness: {Happiness}");
            }
            else
            {
                Console.WriteLine($"{Name} is Fully Ready!");
            }
        }

        public void PassTime()
        {
            Hunger += 1;
            Happiness -= 1;

            if (Hunger > 10) Hunger = 10;
            if (Happiness < 0) Happiness = 0;

            // Consequences for neglect
            if (Hunger >= 10)
            {
                Health -= 1;
                Console.WriteLine($"{Name} is so hungry! Health: {Health}");
            }

            if (Happiness <= 0)
            {
                Health -= 1;
                Console.WriteLine($"{Name} is sad! Health: {Health}");
            }

            if (Health <= 0)
            {
                Console.WriteLine($"{Name} has passed away.");
                Environment.Exit(0);
            }
        }
    }
}
