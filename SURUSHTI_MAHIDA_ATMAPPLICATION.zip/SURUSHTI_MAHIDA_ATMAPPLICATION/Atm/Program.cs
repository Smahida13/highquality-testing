﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ATMSimulator// by surushti mahida
{
    // Account
    public class Account
    {
        public int AccountNumber { get; private set; }
        public decimal Balance { get; private set; }
        public decimal InterestRate { get; private set; }
        public string AccountHolderName { get; private set; }
        private List<string> Transactions;

        public Account(int accountNo, decimal initialBalance, decimal interestRate, string accountHolderName)
        {
            AccountNumber = accountNo;
            Balance = initialBalance;
            InterestRate = interestRate;
            AccountHolderName = accountHolderName;
            Transactions = new List<string>();
        }

        public decimal Deposit(decimal amount)
        {
            Balance += amount;
            Transactions.Add($"Deposited: {amount}");
            return Balance;
        }

        public decimal Withdraw(decimal amount)
        {
            if (amount <= Balance)
            {
                Balance -= amount;
                Transactions.Add($"Withdrawn: {amount}");
                return Balance;
            }
            throw new InvalidOperationException("Insufficient funds.");
        }

        public decimal CheckBalance() => Balance;

        public List<string> GetTransactions() => Transactions;

        public decimal CalculateInterest() => Balance * (InterestRate / 100);
    }

    // Bank 
    public class Bank
    {
        private List<Account> Accounts;

        public Bank()
        {
            Accounts = new List<Account>();
            for (int i = 100; i < 110; i++)
            {
                Accounts.Add(new Account(i, 100, 3, $"Account Holder {i}"));
            }
        }

        public void AddAccount(Account account) => Accounts.Add(account);

        public Account RetrieveAccount(int accountNumber)
        {
            return Accounts.FirstOrDefault(a => a.AccountNumber == accountNumber);
        }
    }

    // ATM 
    public class AtmApp
    {
        private Bank bank;
        private Account currentAccount;

        public AtmApp()
        {
            bank = new Bank();
        }

        public void DisplayMainMenu()
        {
            while (true)
            {
                Console.WriteLine("ATM Main Menu:");
                Console.WriteLine("1. Create Account");
                Console.WriteLine("2. Select Account");
                Console.WriteLine("3. Exit");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        CreateAccount();
                        break;
                    case "2":
                        SelectAccount();
                        break;
                    case "3":
                        ExitApplication();
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        public void CreateAccount()
        {
            Console.Write("Enter Account Number (100-1000): ");
            int accountNumber = int.Parse(Console.ReadLine());
            Console.Write("Enter Initial Balance (>=0): ");
            decimal initialBalance = decimal.Parse(Console.ReadLine());
            Console.Write("Enter Annual Interest Rate (in %): ");
            decimal interestRate = decimal.Parse(Console.ReadLine());
            Console.Write("Enter Account Holder's Name: ");
            string accountHolderName = Console.ReadLine();

            Account newAccount = new Account(accountNumber, initialBalance, interestRate, accountHolderName);
            bank.AddAccount(newAccount);
            Console.WriteLine("Account created successfully!");
        }

        public void SelectAccount()
        {
            Console.Write("Enter Account Number: ");
            int accountNumber = int.Parse(Console.ReadLine());
            currentAccount = bank.RetrieveAccount(accountNumber);

            if (currentAccount != null)
            {
                DisplayAccountMenu();
            }
            else
            {
                Console.WriteLine("Account not found.");
            }
        }

        public void DisplayAccountMenu()
        {
            while (true)
            {
                Console.WriteLine($"Account Menu for {currentAccount.AccountHolderName}:");
                Console.WriteLine("1. Check Balance");
                Console.WriteLine("2. Deposit");
                Console.WriteLine("3. Withdraw");
                Console.WriteLine("4. Display Transactions");
                Console.WriteLine("5. Exit Account");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.WriteLine($"Balance: {currentAccount.CheckBalance()}");
                        break;
                    case "2":
                        Console.Write("Enter amount to deposit: ");
                        decimal depositAmount = decimal.Parse(Console.ReadLine());
                        Console.WriteLine($"New Balance: {currentAccount.Deposit(depositAmount)}");
                        break;
                    case "3":
                        Console.Write("Enter amount to withdraw: ");
                        decimal withdrawAmount = decimal.Parse(Console.ReadLine());
                        try
                        {
                            Console.WriteLine($"New Balance: {currentAccount.Withdraw(withdrawAmount)}");
                        }
                        catch (InvalidOperationException e)
                        {
                            Console.WriteLine(e.Message);
                        }
                        break;
                    case "4":
                        var transactions = currentAccount.GetTransactions();
                        foreach (var transaction in transactions)
                        {
                            Console.WriteLine(transaction);
                        }
                        break;
                    case "5":
                        return;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }

        public void ExitApplication()
        {
            Console.WriteLine("Thank you for using the ATM application. Goodbye!");
        }
    }

    // Main method
    class Program
    {
        static void Main(string[] args)
        {
            AtmApp atmApp = new AtmApp();
            atmApp.DisplayMainMenu();
        }
    }
}